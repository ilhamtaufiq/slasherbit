# Stratigility

> From "Strata", Latin for "layer", and "agility".

Stratigility started as a port of [Sencha Connect](https://github.com/senchalabs/connect)
to PHP. It allows you to build applications out of _middleware_.
