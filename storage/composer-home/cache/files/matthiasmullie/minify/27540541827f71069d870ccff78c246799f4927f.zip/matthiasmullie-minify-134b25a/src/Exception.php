<?php

namespace MatthiasMullie\Minify;

/**
 * @deprecated Use Exceptions\BasicException instead
 *
 * @author Matthias Mullie <minify@mullie.eu>
 */
abstract class Exception extends \Exception
{
}
