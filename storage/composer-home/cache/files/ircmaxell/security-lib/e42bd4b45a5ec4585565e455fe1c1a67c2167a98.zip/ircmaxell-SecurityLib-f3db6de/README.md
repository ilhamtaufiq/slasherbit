SecurityLib
===========

This is a base set of libraries used in other projects. This isn't useful on its own...


License
-------

MIT, see LICENSE.

Security Vulnerabilities
========================

If you have found a security issue, please contact the author directly at [me@ircmaxell.com](mailto:me@ircmaxell.com).
